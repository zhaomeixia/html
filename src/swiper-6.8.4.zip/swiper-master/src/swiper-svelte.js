/* eslint-disable */
import Swiper from './svelte/swiper';
import SwiperSlide from './svelte/swiper-slide';

export { Swiper, SwiperSlide };
